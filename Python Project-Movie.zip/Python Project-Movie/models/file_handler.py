
from . movie import Movie, Crew
from . main import Menu  
from ast import literal_eval    


class MovieHandler:
    def add_movie(self):
        # get data from input ( user )
        movie_name = input('What is movie name ? : ')
        movie_time = int(input('What is movie time ? : '))
        
        
        menu = Menu()
        menu.show_add_movie_crews_menu()
        movie = Movie(movie_name, movie_time)   
        while True:
            item = int(input('Add Crews . . . : '))   
            if item == 1:
                                
                salary = int(input('Salary ? : '))
                first_name = input('First Name ? : ')
                last_name = input('Last Name ? : ')
                born = input('Born ? : ')   
                nat = input('Nationality ? : ')
                role = input('Role ? ( c = cast | w = writer | d = director ) : ')
                
                cast = Crew(salary, first_name, last_name, born, nat, role)
                movie.add_cast(cast)   
            elif item == 2:
                print('Add Director')   
            elif item == 3:
                print('Add Writer')
            elif item == 0:
                print('Saving . . . ')
                break   
            else:
                print('Wrong Input !')
        
        


        # insert data to file 
        try:
            f = open('storage/movie.txt', 'a')   
            f.write(movie.get_movie_info() + '\n')
            
            f.close()
             
        
        except Exception as e:
            print('Error: ', e)

    
    def show_all_movies(self):
        try:
            
            f = open('storage/movie.txt', 'r')   
            
            lines = f.readlines()
            for line in lines:
                print(literal_eval(line).get('Name'))   
            f.close()
             
        except Exception as e:
            print('Error: ', e)


    def search_movie(self):
        movie_name = input('What are you looking for ? : ')   
        try:
            f = open('storage/movie.txt', 'r')
            lines = f.readlines()
            is_find = False

            for line in lines:
                dict_line = literal_eval(line)    
                if dict_line.get('Name').lower() == movie_name.lower():
                    
                    print('Name : ', dict_line.get('Name'))   
                    print('Time : ', dict_line.get('Time'))
                    print('Publish Date : ', dict_line.get('Publish Date'))
                    is_find = True

            f.close()
            if not is_find:
                print('Cannot find the movie \'{}\''.format(movie_name))
                            
        except Exception as e:
            print('Error: ', e)


    def update_movie(self):
        movie_name = input('What movie do you want to UPDATE ? : ')
        try:
            fr = open('storage/movie.txt', 'r')   
            lines = fr.readlines()
            fw = open('storage/movie.txt', 'w')   
            update_line = None
            for line in lines:
                if literal_eval(line).get('Name').lower() != movie_name.lower():
                    fw.write(line)
                else:   
                        update_line = literal_eval(line) 
                        new_time = int(input('New Time ? : '))
                        update_line['Time'] = new_time
            fr.close()
            fw.close()
            if update_line != None:
                fa = open('storage/movie.txt', 'a')
                fa.write(str(update_line) + '\n')
                fa.close()

        except Exception as e:
            print('Error : ', e)

    
    
    def delete_movie(self):    
        movie_name = input('What movie do you want to DELETE ? : ')
        try:
            
            fin = open('storage/movie.txt', 'r')   
            lines = fin.readlines()   
            
            fout = open('storage/movie.txt', 'w')
            for line in lines:
                if literal_eval(line).get('Name').lower() != movie_name.lower():
                    fout.write(line)        
            
            fin.close()
            fout.close()

        except Exception as e: 
            print('Error : ', e)



