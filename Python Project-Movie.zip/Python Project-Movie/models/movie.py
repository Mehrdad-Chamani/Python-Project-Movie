import datetime
from . person import Person

class Crew(Person):
    def __init__(self, salary, first_name, last_name, born, nationality, role):
        super().__init__(first_name, last_name, born, nationality, role)
        self.salary = salary

    # def get_crew(self):   
    #     return {
    #         'Person': super().get_person(),
    #         'Salary': self.salary
    #         }

    def get_crew(self):   
        return {
            'Person': super().__str__(),
            'Salary': self.salary
            }


class Movie:
    casts = []   
    crews = []

     
    def __init__(self, name, time, publish_date= None, *crews: Crew):   
        self.name = name
        self.time = time
        self.crews = crews
        
        self.publish_date = publish_date if publish_date != None else datetime.datetime.now()
    
    
    def get_movie_info(self):    
        return str({
            'Name': self.name,
            'Time': self.time,
            'Publish Date': self.publish_date.strftime('%d %m %Y'),
            
            'Casts': self.get_casts(), 
            'Crews': self.get_crews(),    
            
        })

    
    def add_cast(self, cast: Crew):   
        self.casts.append(cast) 


    def get_casts(self):    
        all_casts = []    
        for cast in self.casts:
            all_casts.append(cast.get_crew()) 

        return all_casts

    
    def get_crews(self):   
        all_crews = []
        for crew in self.crews:
            all_crews.append(crew.get_crew())   

        return all_crews
