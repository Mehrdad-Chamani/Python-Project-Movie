# Functions & Class & global Variables

class Menu():
                                
    def show_menu(self):
        print('* * * * * * * * * * * * * * * * * * * * * * * *')
        print('1 - Add Movie')
        print('2 - Show All Movies')
        print('3 - Search Movie')
        print('4 - Update Movie')
        print('5 - Delete Movie')
        print('0 - Exit')
        print('* * * * * * * * * * * * * * * * * * * * * * * *')


    def show_add_movie_crews_menu(self):   
        print('1 - Add Cast')
        print('2 - Add Director')
        print('3 - Add Writer')
        print('0 - Save Movie')   
        


