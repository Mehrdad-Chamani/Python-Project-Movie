import datetime

from models.main import Menu
from models.movie import (Movie, Crew)
from models.person import Person
from models.file_handler import MovieHandler


menu = Menu()
menu.show_menu()
handler = MovieHandler()


def loop_menu():
    while True:
        try:
            item = int(input('Choose an item . . . : '))
            if item == 1:
                handler.add_movie()
            elif item == 2:
                #print('Show All')
                handler.show_all_movies()
            elif item == 3:
                #print('Search Movies')
                handler.search_movie()
            elif item == 4:
                #print('Update Movies')
                handler.update_movie()
            elif item == 5:
                #print('Delete Movie')
                handler.delete_movie()
            elif item == 0:
                #print('Do you want to Exit or not ?')
                exit()
            else:
                #print('! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! !')
                print('________________________')
                print('WRONG ITEM!')
                menu.show_menu()

        except Exception as e:
            print('Error. Invalid input! MUST be an integer number (0-5)\n', e)
            menu.show_menu()
            loop_menu()


loop_menu()


# Run Project :
# 1. Activation Shell ---> pipenv shell
# 2. Select Interpreter
    


